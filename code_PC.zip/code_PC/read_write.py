import serial.tools.list_ports
import time
import numpy as np

ports = serial.tools.list_ports.comports()
serialInst = serial.Serial()

portsList = []

for onePort in ports:
    portsList.append(str(onePort))
    print(str(onePort))

val = input("Select Port: COM")

for x in range(len(portsList)):
    if portsList[x].startswith("COM" + str(val)):
        portVar = "COM" + str(val)
        print("Đã chọn cổng:", portVar)

serialInst.baudrate = 115200
serialInst.port = portVar
serialInst.open()
time.sleep(2)  # Chờ cổng ổn định

# Mảng dữ liệu cần gửi


lo_trinh_bay = [
    [1035, 800  , 400, 1, 1, 1, 8],
    [650, 1190  , 400, 2, 1, 0, 8],
    [840, 1170  , 400, 3, 1, 1, 8],
    [1115, 1195  , 400, 4, 1, 0, 8],
    [1410, 1205  , 400, 5, 1, 1, 8],
    [990, 60  , 400, 6, 1, 0, 8],
    [990, 60   ,-100, 7, 1, 0, 8],
    [990, 60   ,-100, 8, 1, 0, 8],
]
# lo_trinh_bay = [
#     [230,   460,  400, 1, 1, 1, 7],
#     [335,   535,  400, 2, 1, 0, 7],
#     [375,   645,  400, 3, 1, 1, 7],
#     [490,   335,  400, 4, 1, 0, 7],
#     [590,   565,  400, 5, 1, 0, 7],
#     [840,   480,  400, 6, 0, 0, 7],
#     [840,   480, -100, 7, 1, 0, 7],
# ]



print("Mảng dữ liệu cần gửi:")
print(lo_trinh_bay)

# Gửi dữ liệu trong 4 giây
print("=== Bắt đầu gửi dữ liệu trong 4 giây ===")
start_time = time.time()
while time.time() - start_time < 4:
    for row in lo_trinh_bay:
        x = row[0]
        y = row[1]
        h = row[2]
        stt = row[3]
        nvo = row[4]
        nvi = row[5]
        sl = row[6]
        
        row_data = f"x{x}y{y}h{h}stt{stt}nvo{nvo}nvi{nvi}sl{sl}end\n"
        serialInst.write(row_data.encode('utf-8'))
        time.sleep(0.001)  # Delay nhỏ để thiết bị nhận kịp

print("=== Dừng gửi, bắt đầu đọc dữ liệu ===")

# Đọc dữ liệu liên tục sau khi gửi xong
while True:
    if serialInst.in_waiting:
        packet = serialInst.readline()
        line = packet.decode('utf-8', errors='ignore').rstrip('\n')
        print(f"Nhận được: {line}")
    time.sleep(0.001)
