import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import serial.tools.list_ports
import serial
import time
import threading
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import json
import os

class DroneMapControl:
    def __init__(self, root):
        self.root = root
        self.root.title("Drone Map Control System")
        self.root.geometry("1400x800")

        # Define the file path for saving map data
        self.map_data_file = "drone_maps.json"

        # Serial connection
        self.serial_connection = None
        self.is_reading = False
        self.read_thread = None

        # Map data - 10 maps with 7 points each
        self.maps = self.load_maps() # Load maps from file or use default

        self.current_map = "Map 1" # Default map to load

        self.setup_ui()
        self.update_map_display()

    def load_maps(self):
        """Loads map data from a JSON file. If the file doesn't exist, it returns default maps."""
        if os.path.exists(self.map_data_file):
            try:
                with open(self.map_data_file, 'r') as f:
                    maps = json.load(f)
                    print(f"Loaded maps from {self.map_data_file}")
                    return maps
            except json.JSONDecodeError:
                messagebox.showerror("Error", "Failed to decode map data file. Using default maps.")
                return self._get_default_maps()
        else:
            print("Map data file not found. Creating with default maps.")
            return self._get_default_maps()

    def save_maps(self):
        """Saves the current map data to a JSON file."""
        try:
            with open(self.map_data_file, 'w') as f:
                json.dump(self.maps, f, indent=4)
            print(f"Maps saved to {self.map_data_file}")
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save map data: {str(e)}")

    def _get_default_maps(self):
        """Returns the default map data."""
        return {
            "Map 1": [
                [1035, 800, 400, 1, 1, 10, 7],
                [650, 1190, 400, 2, 1, 10, 7],
                [840, 1170, 400, 3, 1, 10, 7],
                [1115, 1195, 400, 4, 1, 10, 7],
                [1410, 1205, 400, 5, 1, 10, 7],
                [990, 60, 400, 6, 1, 50, 7],
                [990, 60, -50, 7, 1, 50, 7],
            ],
            "Map 2": [
                [200, 300, 400, 1, 1, 10, 7],
                [500, 800, 400, 2, 1, 10, 7],
                [800, 1200, 400, 3, 1, 10, 7],
                [1100, 1600, 400, 4, 1, 10, 7],
                [300, 2000, 400, 5, 1, 10, 7],
                [700, 2200, 400, 6, 1, 50, 7],
                [1000, 100, -50, 7, 1, 50, 7],
            ],
            "Map 3": [
                [100, 100, 400, 1, 1, 10, 7],
                [400, 400, 400, 2, 1, 10, 7],
                [700, 700, 400, 3, 1, 10, 7],
                [1000, 1000, 400, 4, 1, 10, 7],
                [1200, 1300, 400, 5, 1, 10, 7],
                [900, 1600, 400, 6, 1, 50, 7],
                [600, 1900, -50, 7, 1, 50, 7],
            ],
            "Map 4": [
                [300, 500, 400, 1, 1, 10, 7],
                [600, 900, 400, 2, 1, 10, 7],
                [900, 1300, 400, 3, 1, 10, 7],
                [1200, 1700, 400, 4, 1, 10, 7],
                [500, 2100, 400, 5, 1, 10, 7],
                [800, 2300, 400, 6, 1, 50, 7],
                [1100, 200, -50, 7, 1, 50, 7],
            ],
            "Map 5": [
                [150, 250, 400, 1, 1, 10, 7],
                [450, 650, 400, 2, 1, 10, 7],
                [750, 1050, 400, 3, 1, 10, 7],
                [1050, 1450, 400, 4, 1, 10, 7],
                [350, 1850, 400, 5, 1, 10, 7],
                [650, 2150, 400, 6, 1, 50, 7],
                [950, 150, -50, 7, 1, 50, 7],
            ],
            "Map 6": [
                [250, 400, 400, 1, 1, 10, 7],
                [550, 700, 400, 2, 1, 10, 7],
                [850, 1000, 400, 3, 1, 10, 7],
                [1150, 1300, 400, 4, 1, 10, 7],
                [450, 1600, 400, 5, 1, 10, 7],
                [750, 1900, 400, 6, 1, 50, 7],
                [1050, 300, -50, 7, 1, 50, 7],
            ],
            "Map 7": [
                [350, 600, 400, 1, 1, 10, 7],
                [650, 1000, 400, 2, 1, 10, 7],
                [950, 1400, 400, 3, 1, 10, 7],
                [1250, 1800, 400, 4, 1, 10, 7],
                [550, 2200, 400, 5, 1, 10, 7],
                [850, 2400, 400, 6, 1, 50, 7],
                [1150, 100, -50, 7, 1, 50, 7],
            ],
            "Map 8": [
                [400, 200, 400, 1, 1, 10, 7],
                [700, 600, 400, 2, 1, 10, 7],
                [1000, 1000, 400, 3, 1, 10, 7],
                [1300, 1400, 400, 4, 1, 10, 7],
                [600, 1800, 400, 5, 1, 10, 7],
                [900, 2200, 400, 6, 1, 50, 7],
                [1200, 50, -50, 7, 1, 50, 7],
            ],
            "Map 9": [
                [500, 350, 400, 1, 1, 10, 7],
                [800, 750, 400, 2, 1, 10, 7],
                [1100, 1150, 400, 3, 1, 10, 7],
                [1400, 1550, 400, 4, 1, 1, 7],
                [700, 1950, 400, 5, 1, 10, 7],
                [1000, 2350, 400, 6, 1, 50, 7],
                [1300, 200, -50, 7, 1, 50, 7],
            ],
            "Map 10": [
                [600, 450, 400, 1, 1, 10, 7],
                [900, 850, 400, 2, 1, 10, 7],
                [1200, 1250, 400, 3, 1, 10, 7],
                [1500, 1650, 400, 4, 1, 10, 7],
                [800, 2050, 400, 5, 1, 10, 7],
                [1100, 2450, 400, 6, 1, 50, 7],
                [1400, 350, -50, 7, 1, 50, 7],
            ],
            "Map 11": [
                [1035, 800, 400, 1, 1, 10, 7],
                [650, 1190, 400, 2, 1, 10, 7],
                [840, 1170, 400, 3, 1, 10, 7],
                [1115, 1195, 400, 4, 1, 10, 7],
                [1410, 1205, 400, 5, 1, 10, 7],
                [990, 60, 400, 6, 1, 50, 7],
                [990, 60, -50, 7, 1, 50, 7],
            ],
            "Map 12": [
                [200, 300, 400, 1, 1, 10, 7],
                [500, 800, 400, 2, 1, 10, 7],
                [800, 1200, 400, 3, 1, 10, 7],
                [1100, 1600, 400, 4, 1, 10, 7],
                [300, 2000, 400, 5, 1, 10, 7],
                [700, 2200, 400, 6, 1, 50, 7],
                [1000, 100, -50, 7, 1, 50, 7],
            ],
            "Map 13": [
                [100, 100, 400, 1, 1, 10, 7],
                [400, 400, 400, 2, 1, 10, 7],
                [700, 700, 400, 3, 1, 10, 7],
                [1000, 1000, 400, 4, 1, 10, 7],
                [1200, 1300, 400, 5, 1, 1, 7],
                [900, 1600, 400, 6, 1, 50, 7],
                [600, 1900, -50, 7, 1, 50, 7],
            ],
            "Map 14": [
                [300, 500, 400, 1, 1, 10, 7],
                [600, 900, 400, 2, 1, 10, 7],
                [900, 1300, 400, 3, 1, 10, 7],
                [1200, 1700, 400, 4, 1, 10, 7],
                [500, 2100, 400, 5, 1, 10, 7],
                [800, 2300, 400, 6, 1, 50, 7],
                [1100, 200, -50, 7, 1, 50, 7],
            ],
            "Map 15": [
                [150, 250, 400, 1, 1, 10, 7],
                [450, 650, 400, 2, 1, 10, 7],
                [750, 1050, 400, 3, 1, 10, 7],
                [1050, 1450, 400, 4, 1, 10, 7],
                [350, 1850, 400, 5, 1, 10, 7],
                [650, 2150, 400, 6, 1, 50, 7],
                [950, 150, -50, 7, 1, 50, 7],
            ],
            "Map 16": [
                [250, 400, 400, 1, 1, 10, 7],
                [550, 700, 400, 2, 1, 10, 7],
                [850, 1000, 400, 3, 1, 10, 7],
                [1150, 1300, 400, 4, 1, 10, 7],
                [450, 1600, 400, 5, 1, 10, 7],
                [750, 1900, 400, 6, 1, 50, 7],
                [1050, 300, -50, 7, 1, 50, 7],
            ],
            "Map 17": [
                [350, 600, 400, 1, 1, 10, 7],
                [650, 1000, 400, 2, 1, 10, 7],
                [950, 1400, 400, 3, 1, 10, 7],
                [1250, 1800, 400, 4, 1, 10, 7],
                [550, 2200, 400, 5, 1, 10, 7],
                [850, 2400, 400, 6, 1, 50, 7],
                [1150, 100, -50, 7, 1, 50, 7],
            ],
            "Map 18": [
                [400, 200, 400, 1, 1, 10, 7],
                [700, 600, 400, 2, 1, 10, 7],
                [1000, 1000, 400, 3, 1, 10, 7],
                [1300, 1400, 400, 4, 1, 10, 7],
                [600, 1800, 400, 5, 1, 10, 7],
                [900, 2200, 400, 6, 1, 50, 7],
                [1200, 50, -50, 7, 1, 50, 7],
            ],
            "Map 19": [
                [500, 350, 400, 1, 1, 10, 7],
                [800, 750, 400, 2, 1, 10, 7],
                [1100, 1150, 400, 3, 1, 10, 7],
                [1400, 1550, 400, 4, 1, 1, 7],
                [700, 1950, 400, 5, 1, 10, 7],
                [1000, 2350, 400, 6, 1, 50, 7],
                [1300, 200, -50, 7, 1, 50, 7],
            ],
            "Map 20": [
                [600, 450, 400, 1, 1, 10, 7],
                [900, 850, 400, 2, 1, 10, 7],
                [1200, 1250, 400, 3, 1, 10, 7],
                [1500, 1650, 400, 4, 1, 10, 7],
                [800, 2050, 400, 5, 1, 10, 7],
                [1100, 2450, 400, 6, 1, 50, 7],
                [1400, 350, -50, 7, 1, 50, 7],
            ]
        }

    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create a PanedWindow to allow resizing
        # We'll put the map visualization and the combined controls/data on either side
        self.paned_window = ttk.PanedWindow(main_frame, orient=tk.HORIZONTAL)
        self.paned_window.pack(fill=tk.BOTH, expand=True)

        # Left panel for map visualization (make it larger)
        map_viz_panel = ttk.Frame(self.paned_window)
        self.paned_window.add(map_viz_panel, weight=3) # Assign more weight to the map panel

        # Map visualization
        map_viz_frame = ttk.LabelFrame(map_viz_panel, text="Map Visualization")
        map_viz_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Create matplotlib figure
        self.fig, self.ax = plt.subplots(figsize=(8, 6))
        self.canvas = FigureCanvasTkAgg(self.fig, map_viz_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Right panel for controls and data display
        right_combined_panel = ttk.Frame(self.paned_window)
        self.paned_window.add(right_combined_panel, weight=1) # Less weight for controls/data

        # Map selection
        map_frame = ttk.LabelFrame(right_combined_panel, text="Map Selection")
        map_frame.pack(fill=tk.X, pady=(0, 10), padx=5)

        self.map_var = tk.StringVar(value=self.current_map)
        self.map_combo = ttk.Combobox(map_frame, textvariable=self.map_var,
                                         values=list(self.maps.keys()), state="readonly")
        self.map_combo.pack(pady=5, fill=tk.X)
        self.map_combo.bind('<<ComboboxSelected>>', self.on_map_change)

        # Serial port selection
        serial_frame = ttk.LabelFrame(right_combined_panel, text="Serial Connection")
        serial_frame.pack(fill=tk.X, pady=(0, 10), padx=5)

        ttk.Label(serial_frame, text="COM Port:").pack(anchor=tk.W)
        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(serial_frame, textvariable=self.port_var)
        self.port_combo.pack(pady=5, fill=tk.X)

        ttk.Button(serial_frame, text="Refresh Ports",
                           command=self.refresh_ports).pack(pady=2, fill=tk.X)

        self.connect_btn = ttk.Button(serial_frame, text="Connect",
                                         command=self.toggle_connection)
        self.connect_btn.pack(pady=2, fill=tk.X)

        self.status_label = ttk.Label(serial_frame, text="Disconnected",
                                         foreground="red")
        self.status_label.pack(pady=2)

        # Send data button
        self.send_btn = ttk.Button(right_combined_panel, text="Send Map Data",
                                       command=self.send_map_data, state=tk.DISABLED)
        self.send_btn.pack(pady=10, fill=tk.X, padx=5)

        # Map coordinates display
        coord_frame = ttk.LabelFrame(right_combined_panel, text="Map Coordinates")
        coord_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10), padx=5)

        # Create treeview for coordinates
        columns = ('Point', 'X', 'Y', 'Z', 'STT', 'NVO', 'NVI', 'SL')
        self.coord_tree = ttk.Treeview(coord_frame, columns=columns, show='headings', height=8)

        for col in columns:
            self.coord_tree.heading(col, text=col)
            # Adjust column widths for better readability
            if col == 'Point':
                self.coord_tree.column(col, width=40, anchor=tk.CENTER)
            else:
                self.coord_tree.column(col, width=60, anchor=tk.CENTER) # Wider columns for data

        scrollbar_tree = ttk.Scrollbar(coord_frame, orient=tk.VERTICAL, command=self.coord_tree.yview)
        self.coord_tree.configure(yscrollcommand=scrollbar_tree.set)

        self.coord_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_tree.pack(side=tk.RIGHT, fill=tk.Y)

        # Bind double-click to edit coordinates
        self.coord_tree.bind('<Double-1>', self.edit_coordinate)

        # Edit buttons
        edit_buttons_frame = ttk.Frame(right_combined_panel) # Moved to the right panel
        edit_buttons_frame.pack(fill=tk.X, pady=5, padx=5)

        ttk.Button(edit_buttons_frame, text="Edit Selected",
                           command=self.edit_selected_coordinate).pack(side=tk.LEFT, padx=2, expand=True)
        ttk.Button(edit_buttons_frame, text="Save Current Map",
                           command=self.save_current_map).pack(side=tk.LEFT, padx=2, expand=True)
        ttk.Button(edit_buttons_frame, text="Reset Map",
                           command=self.reset_current_map).pack(side=tk.LEFT, padx=2, expand=True)
        ttk.Button(edit_buttons_frame, text="Save All Maps",
                           command=self.save_maps).pack(side=tk.LEFT, padx=2, expand=True)

        # Serial data display (also moved to the right panel)
        data_frame = ttk.LabelFrame(right_combined_panel, text="Received Data")
        data_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=(0,5))

        self.data_text = scrolledtext.ScrolledText(data_frame, height=10, wrap=tk.WORD)
        self.data_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)


        # Initialize
        self.refresh_ports()

    def refresh_ports(self):
        ports = serial.tools.list_ports.comports()
        port_list = [str(port).split()[0] for port in ports]
        self.port_combo['values'] = port_list
        if port_list:
            self.port_combo.set(port_list[0])

    def toggle_connection(self):
        if self.serial_connection is None or not self.serial_connection.is_open:
            self.connect_serial()
        else:
            self.disconnect_serial()

    def connect_serial(self):
        try:
            port = self.port_var.get()
            if not port:
                messagebox.showerror("Error", "Please select a COM port")
                return

            self.serial_connection = serial.Serial(port, 115200, timeout=1)
            time.sleep(2)  # Wait for port to stabilize

            self.status_label.config(text="Connected", foreground="green")
            self.connect_btn.config(text="Disconnect")
            self.send_btn.config(state=tk.NORMAL)

            # Start reading thread
            self.is_reading = True
            self.read_thread = threading.Thread(target=self.read_serial_data, daemon=True)
            self.read_thread.start()

            self.log_data(f"Connected to {port}")

        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect: {str(e)}")

    def disconnect_serial(self):
        self.is_reading = False
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()

        self.status_label.config(text="Disconnected", foreground="red")
        self.connect_btn.config(text="Connect")
        self.send_btn.config(state=tk.DISABLED)

        self.log_data("Disconnected from serial port")

    def read_serial_data(self):
        while self.is_reading and self.serial_connection and self.serial_connection.is_open:
            try:
                if self.serial_connection.in_waiting:
                    packet = self.serial_connection.readline()
                    line = packet.decode('utf-8', errors='ignore').rstrip('\n')
                    if line:
                        self.log_data(f"Received: {line}")
                time.sleep(0.001)
            except Exception as e:
                self.log_data(f"Read error: {str(e)}")
                break

    def log_data(self, message):
        timestamp = time.strftime("%H:%M:%S")
        self.data_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.data_text.see(tk.END)

    def on_map_change(self, event):
        self.current_map = self.map_var.get()
        self.update_map_display()
        self.update_coordinate_table()

    def update_coordinate_table(self):
        # Clear existing items
        for item in self.coord_tree.get_children():
            self.coord_tree.delete(item)

        # Add current map data
        map_data = self.maps[self.current_map]
        for i, row in enumerate(map_data, 1):
            self.coord_tree.insert('', 'end', values=(i, row[0], row[1], row[2],
                                                     row[3], row[4], row[5], row[6]))

    def update_map_display(self):
        self.ax.clear()

        # Set fixed limits for X and Y axes
        self.ax.set_xlim(-100, 1200)
        self.ax.set_ylim(-100, 2400)
        
        # Set aspect ratio to be equal, so 1cm on X is same length as 1cm on Y
        self.ax.set_aspect('equal', adjustable='box')

        self.ax.set_xlabel('X (cm)')
        self.ax.set_ylabel('Y (cm)')
        self.ax.set_title(f'Map Visualization - {self.current_map}')
        
        # Add major grid lines every 100cm (1 meter)
        self.ax.xaxis.set_major_locator(plt.MultipleLocator(100))
        self.ax.yaxis.set_major_locator(plt.MultipleLocator(100))
        self.ax.grid(True, which='major', color='gray', linestyle='-', linewidth=0.7, alpha=0.5)

        # Add minor grid lines every 50cm (0.5 meter) for more detail
        self.ax.xaxis.set_minor_locator(plt.MultipleLocator(50))
        self.ax.yaxis.set_minor_locator(plt.MultipleLocator(50))
        self.ax.grid(True, which='minor', color='lightgray', linestyle=':', linewidth=0.5, alpha=0.3)


        # Plot current map points
        map_data = self.maps[self.current_map]
        for i, point in enumerate(map_data):
            x, y, z = point[0], point[1], point[2]
            stt = point[3]

            # Color based on height
            color = 'red' if z < 0 else 'blue'

            # Plot point
            self.ax.scatter(x, y, c=color, s=100, alpha=0.7)

            # Add point label
            self.ax.annotate(f'{stt}', (x, y), xytext=(5, 5),
                                 textcoords='offset points', fontsize=8)

        self.canvas.draw()
        self.update_coordinate_table()

    def send_map_data(self):
        if not self.serial_connection or not self.serial_connection.is_open:
            messagebox.showerror("Error", "Serial connection not established")
            return

        try:
            map_data = self.maps[self.current_map]
            self.log_data(f"Starting to send {self.current_map} data for 4 seconds...")

            # Send data for 4 seconds
            start_time = time.time()
            count = 0
            while time.time() - start_time < 4:
                for row in map_data:
                    x, y, h, stt, nvo, nvi, sl = row
                    row_data = f"x{x}y{y}h{h}stt{stt}nvo{nvo}nvi{nvi}sl{sl}end\n"
                    self.serial_connection.write(row_data.encode('utf-8'))
                    count += 1
                    time.sleep(0.001)

            self.log_data(f"Finished sending data. Sent {count} packets.")

        except Exception as e:
            messagebox.showerror("Send Error", f"Failed to send data: {str(e)}")
            self.log_data(f"Send error: {str(e)}")

    def edit_coordinate(self, event):
        """Handle double-click on coordinate tree"""
        selection = self.coord_tree.selection()
        if selection:
            self.edit_selected_coordinate()

    def edit_selected_coordinate(self):
        """Edit the selected coordinate"""
        selection = self.coord_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a coordinate to edit")
            return

        item = selection[0]
        values = self.coord_tree.item(item)['values']
        point_index = int(values[0]) - 1  # Convert to 0-based index

        # Create edit dialog
        self.create_edit_dialog(point_index, values)

    def create_edit_dialog(self, point_index, current_values):
        """Create dialog for editing coordinate values"""
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Edit Point {point_index + 1}")
        dialog.geometry("300x400")
        dialog.resizable(False, False)

        # Make dialog modal
        dialog.transient(self.root)
        dialog.grab_set()

        # Center the dialog
        dialog.geometry("+%d+%d" % (self.root.winfo_rootx() + 50, self.root.winfo_rooty() + 50))

        # Entry variables
        vars_dict = {}
        labels = ['X (cm)', 'Y (cm)', 'Z (cm)', 'STT', 'NVO', 'NVI', 'SL']

        # Create entry fields
        for i, (label, value) in enumerate(zip(labels, current_values[1:])):  # Skip Point column
            frame = ttk.Frame(dialog)
            frame.pack(fill=tk.X, padx=10, pady=5)

            ttk.Label(frame, text=label, width=10).pack(side=tk.LEFT)
            var = tk.StringVar(value=str(value))
            vars_dict[i] = var
            entry = ttk.Entry(frame, textvariable=var, width=15)
            entry.pack(side=tk.RIGHT, padx=5)

        # Buttons frame
        button_frame = ttk.Frame(dialog)
        button_frame.pack(fill=tk.X, padx=10, pady=20)

        def save_changes():
            try:
                # Validate and get new values
                new_values = []
                for i in range(7):  # X, Y, Z, STT, NVO, NVI, SL
                    value = vars_dict[i].get().strip()
                    if i < 3:  # X, Y, Z can be negative
                        new_values.append(int(value))
                    else:  # STT, NVO, NVI, SL should be positive
                        new_values.append(int(value))

                # Update the map data
                self.maps[self.current_map][point_index] = new_values

                # Refresh displays
                self.update_map_display()
                self.update_coordinate_table()

                # Log the change
                self.log_data(f"Updated {self.current_map} Point {point_index + 1}: {new_values}")

                dialog.destroy()

            except ValueError as e:
                messagebox.showerror("Invalid Input", "Please enter valid numeric values")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save changes: {str(e)}")

        def cancel_changes():
            dialog.destroy()

        ttk.Button(button_frame, text="Save", command=save_changes).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=cancel_changes).pack(side=tk.RIGHT, padx=5)

        # Instructions
        instruction_text = """Instructions:
 • X, Y: Coordinates in cm (-100 to 1200 for X, -100 to 2400 for Y)
 • Z: Height in cm (can be negative)
 • STT: Sequential number (1-7)
 • NVO: Usually 1
 • NVI: Target radius (0 or 1)
 • SL: Total targets (usually 7)"""

        instruction_label = ttk.Label(dialog, text=instruction_text, justify=tk.LEFT, font=('Arial', 8))
        instruction_label.pack(padx=10, pady=10)

    def save_current_map(self):
        """Save current map changes to the file."""
        self.save_maps()
        messagebox.showinfo("Save", f"{self.current_map} changes saved to file: {self.map_data_file}")
        self.log_data(f"Saved changes to {self.current_map} to file.")

    def reset_current_map(self):
        """Reset current map to default values."""
        result = messagebox.askyesno("Reset Map", f"Are you sure you want to reset {self.current_map} to default values? This cannot be undone unless you have a saved copy.")
        if result:
            default_maps = self._get_default_maps()
            if self.current_map in default_maps:
                self.maps[self.current_map] = [list(point) for point in default_maps[self.current_map]] # Create a deep copy
                self.update_map_display()
                self.update_coordinate_table()
                self.save_maps() # Save reset state to file
                messagebox.showinfo("Reset", f"{self.current_map} has been reset to default values and saved.")
                self.log_data(f"Reset {self.current_map} to default values and saved.")
            else:
                messagebox.showwarning("Warning", "Default data for this map is not available.")
                self.log_data(f"Could not reset {self.current_map}: default data not found.")

def main():
    root = tk.Tk()
    app = DroneMapControl(root)

    def on_closing():
        if app.serial_connection and app.serial_connection.is_open:
            app.disconnect_serial()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()